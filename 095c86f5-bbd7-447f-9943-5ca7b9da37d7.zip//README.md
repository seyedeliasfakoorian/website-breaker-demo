# 2.0-Website-Breaker demo;

This sandbox is a demo of how to use [2.0-website-breaker](https://github.com/seyedeliasfakoorian/2.0-Website-Breaker.git);

The magic happens in the breakButton component inside the component folder;

path : ./src/components/breakButton.jsx
