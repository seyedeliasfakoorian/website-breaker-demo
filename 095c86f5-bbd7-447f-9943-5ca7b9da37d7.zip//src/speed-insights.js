import { injectSpeedInsights } from "@vercel/speed-insights";

injectSpeedInsights();
